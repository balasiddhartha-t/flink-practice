## Scala Examples for "Stream Processing with Apache Flink"

This repository hosts Scala code examples for ["Stream Processing with Apache Flink"](http://shop.oreilly.com/product/0636920057321.do) by [Fabian Hueske](https://twitter.com/fhueske) and [Vasia Kalavri](https://twitter.com/vkalavri).

<a href="http://shop.oreilly.com/product/0636920057321.do">
  <img width="240" src="https://covers.oreillystatic.com/images/0636920057321/cat.gif">
</a>
