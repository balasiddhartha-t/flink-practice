## Java Examples for Stream Processing with Apache Flink

This repository hosts Java code examples for ["Stream Processing with Apache Flink"](http://shop.oreilly.com/product/0636920057321.do) by [Fabian Hueske](https://twitter.com/fhueske) and [Vasia Kalavri](https://twitter.com/vkalavri).

**Note:** The Java examples are not comlete yet. <br>
The [Scala examples](https://github.com/streaming-with-flink/examples-scala) are complete and we are working on translating them to Java.

<a href="http://shop.oreilly.com/product/0636920057321.do">
  <img width="240" src="https://covers.oreillystatic.com/images/0636920057321/cat.gif">
</a>
